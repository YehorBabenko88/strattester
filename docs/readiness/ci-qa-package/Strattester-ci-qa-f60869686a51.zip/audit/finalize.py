from pathlib import Path
import json,hashlib,zipfile,subprocess,io,collections
W=Path(__file__).resolve().parent; R=W/'repo'; E=W/'evidence'; O=W.parent/'outputs'
S='f60869686a51693799b4844a1af49c9b39ba45d5'
sha=lambda b:hashlib.sha256(b).hexdigest()
summary=json.loads((E/'audit-summary.json').read_text())
z=zipfile.ZipFile(E/'artifact-12754132150.zip'); m=json.loads(z.read('build/build-manifest.json'))
assert m['binary_sha256']==sha(z.read('build/StratTester.Native.exe'))==summary['native_binary_sha256']
assert m['source_sha']==S and m['deterministic_rebuild_equal'] is True
for p,h in m['sources'].items():
    assert sha(subprocess.check_output(['git','show',S+':'+p],cwd=R))==h
(E/'native-build-verified.json').write_text(json.dumps(m,indent=2)+'\n')
a=zipfile.ZipFile(E/'offline-build-a.zip');b=zipfile.ZipFile(E/'offline-build-b.zip')
assert {n:a.read(n) for n in a.namelist()}=={n:b.read(n) for n in b.namelist()}
repro={'source_sha':S,'old_builder_a':sha((E/'offline-build-a.zip').read_bytes()),'old_builder_b':sha((E/'offline-build-b.zip').read_bytes()),'equal_members':True,'equal_zip':False,'cause':'ZIP entry wall-clock timestamps'}
(E/'package-reproducibility.json').write_text(json.dumps(repro,indent=2)+'\n')
D=R/'docs/readiness/ci-qa-package';D.mkdir(parents=True,exist_ok=True)
for n in ('audit-summary.json','native-build-verified.json','package-reproducibility.json','local-acceptance.json','local-acceptance.xml','local-acceptance-initial-errors.json'):
    (D/n).write_bytes((E/n).read_bytes())
report=f'''# Exact-source qualification readiness — 2026-10-27

Source PR #21 HEAD refreshed through GitHub and origin before audit: `{S}`.
Tree `0f7626787ec835a9a945a8e576d19181044f23ec`. Audit branch `parallel/ci-qa-package`.
This report qualifies that source commit; documentation commits on this branch are separate and do not inherit its CI results.

## Decision

Software mandatory gates PASS; system acceptance BLOCKED. Physical G0 NOT_COLLECTED; G1 execute/cleanup NOT_AUTHORIZED; deployment/trading NO-GO. No native binary, G1, trading, physical collector, target VM, database or protected host operation executed locally. Hosted native component evidence is reviewed only.

## Independently downloaded evidence

Four exact-head workflow runs; 18 job logs; nine ZIPs with API digest matching SHA256 and verified ZIP CRC. API run head and artifact head bind source. Raw JSON, normalized node IDs and JUnit multisets agree for all 1556 distinct mandatory parent tests. Parameter text is preserved literally. Subtest assertions are not counted as additional parents. Gates: core 594, data 185, math 146, cpu 141, training 66, security 336, integration 88; zero mandatory skips/errors/failures/deselections.

| Run | Result | Scope |
|---|---|---|
| [40548912536](https://github.com/YehorBabenko88/strattester/actions/runs/40548912536) | FAILURE | Seven software gates pass; acceptance BLOCKED/exit 2, failed=[] |
| [40548912336](https://github.com/YehorBabenko88/strattester/actions/runs/40548912336) | SUCCESS | Windows/Linux, Python 3.11/3.13 |
| [40548912423](https://github.com/YehorBabenko88/strattester/actions/runs/40548912423) | SUCCESS | Four reference jobs, 12 passed each |
| [40548912498](https://github.com/YehorBabenko88/strattester/actions/runs/40548912498) | SUCCESS | CPU 76 passed, 2 deselected |

Windows full suite: each 1502 passed, 21 skipped, 21 subtests passed. Linux: each 1476 passed, 47 skipped, 21 subtests passed; Python 3.13 retains 3 warnings. All skip lines and reasons remain in raw logs; these are not zero-skip qualification. Full/reference/CPU runs have no published result artifacts; their accounting is log evidence, unlike mandatory gates. No new workflow was dispatched by this audit.

## Native and integrity

Native source hashes independently match git blobs at the source commit. Hosted build manifest records two equal builds with pinned compiler/reference/BouncyCastle package digests. Actual extracted executable SHA256 is `{m['binary_sha256']}`, matching diagnose and build manifest. Native tests: 30 parents and 4 subtests; receipts retain native_enforcement=false and research_process_created=false. This is COMPONENTS_ONLY, not full isolation. DNS service proxy, filesystem confinement, execution bridge, qualified research transport and output bounds remain missing.

## Acceptance bypass and local tests

Fresh isolated pytest environment, Python 3.15 on Windows: `python -m pytest tests/research/test_financial_acceptance.py tests/research/test_physical_acceptance_attacks.py -q --basetemp=../test-temp-explicit --junitxml=../evidence/local-acceptance.xml --json-report --json-report-file=../evidence/local-acceptance.json`: 23 passed. This is a focused local check, not a full dependency/runtime qualification. Initial attempt 21 passed/2 temp ACL setup errors is retained separately. `pip check` passes for the QA-only environment.

Attack cases cover stale SHA, skipped/failed/error/xfail/xpass/deselected accounting, wrong node sets, reduced gates, cancelled jobs, boolean schema and forged external PASS. Aggregation loads repository manifest and permanently blocks seven physical/external requirements even when caller claims PASS. No admission bypass demonstrated. JSON artifact authenticity itself remains UNVERIFIED_SELF_REPORT; SHA256 proves bytes, not trusted physical facts or owner authority.

## Reproducibility and dependencies

Existing prepare_windows_offline_package.py produced two unequal archive hashes with identical member bytes: `{repro['old_builder_a']}` versus `{repro['old_builder_b']}`. Wall-clock ZIP timestamps prevent byte reproducibility. The delivery archive built for this audit uses sorted entries, fixed timestamps/permissions and ZIP_STORED, and two independent builds must match. This does not claim reproducible wheels or offline dependency installation.

pyproject uses ranged requests/psutil/tzdata, dev/postgres dependencies and setuptools; Torch is exactly pinned. Main Python workflows install from indexes without a complete transitive hash lock and use action version tags; native workflow pins action commits and toolchain package hashes. No vulnerability-free claim, fresh full runtime install, wheelhouse reconstruction or cross-machine package reproduction is established. Existing claimed 160 MB qualification ZIP was not available as a tracked asset or Actions artifact in this audit; its stated hash is not revalidated.

## Findings

| Priority | Finding | Disposition |
|---|---|---|
| P0 | No newly demonstrated acceptance bypass | No claim of absence of all vulnerabilities |
| P1 | PR #21 description claims native SHA256 18f579c8…; exact-head artifact/diagnose/build instead agree on a8420da7… | Use full measured digest above; owner must reconcile stale published evidence before signing |
| P1 | Native components do not enforce a full sandbox; physical identity, authority, paths, snapshot/rollback and private delivery missing | BLOCKED; no G1 authorization |
| P1 | Python dependency closure lacks committed immutable hash lock/wheelhouse | Reproducible offline runtime not established |
| P1 | External grid coherence, real OOS, GPU, upstream parity, physical G0 and owner G1 evidence unavailable | Acceptance remains BLOCKED |
| P2 | Existing offline ZIP builder uses wall-clock timestamps | Reproduced; deterministic audit ZIP supplied without modifying production builder |
| P2 | Full-suite skips, CPU deselections, Linux warnings; initial local temp ACL errors | Preserved, never promoted to executed PASS |

## Owner signing

Use existing TARGET_G0_* templates and the companion OWNER_REVIEW template. All unknown target facts, signer IDs, keys, nonce and times remain null; no signatures fabricated. This is a review template, not an executable authorization or canonical receipt. Package SHA is supplied externally to avoid a hash cycle. A completed declaration cannot clear implemented fail-closed admission by itself.
'''
(D/'READINESS_REPORT.md').write_text(report,encoding='utf-8')
owner={'schema':1,'purpose':'QUALIFICATION_REVIEW_ONLY_NOT_EXECUTION_AUTHORIZATION','source_sha':S,'source_tree':m['tree_sha'],'qualification_zip_sha256':None,'native_binary_sha256':m['binary_sha256'],'owner_id':None,'provider_id':None,'vm_identity':None,'authorized_paths':None,'snapshot_rollback_receipt':None,'private_delivery_receipt':None,'nonce':None,'issued_at':None,'expires_at':None,'owner_signature':None,'provider_signature':None,'physical_g0':'NOT_COLLECTED','g1_execute':'NOT_AUTHORIZED','g1_cleanup':'NOT_AUTHORIZED','trading':'NO-GO'}
(D/'OWNER_REVIEW.template.json').write_text(json.dumps(owner,indent=2)+'\n')
(D/'SHA256SUMS-evidence.txt').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(E.iterdir()) if p.is_file()))
# Byte-exact git source archive avoids CRLF checkout changes.
source=subprocess.check_output(['git','archive','--format=zip',S],cwd=R)
contents={'source.zip':source,'READINESS_REPORT.md':(D/'READINESS_REPORT.md').read_bytes(),'OWNER_REVIEW.template.json':(D/'OWNER_REVIEW.template.json').read_bytes()}
for p in E.iterdir():
    if p.is_file():contents['evidence/'+p.name]=p.read_bytes()
for p in (R/'docs/readiness').glob('TARGET_G0_*'):
    if p.is_file():contents['templates/'+p.name]=p.read_bytes()
contents['audit/collect.py']=(W/'collect.py').read_bytes()
contents['audit/finalize.py']=Path(__file__).read_bytes()
contents['SHA256SUMS.txt']=''.join(sha(v)+'  '+k+'\n' for k,v in sorted(contents.items())).encode()
def build():
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_STORED) as z:
        for n,v in sorted(contents.items()):
            info=zipfile.ZipInfo(n,(1980,1,1,0,0,0));info.create_system=3;info.external_attr=0o100644<<16;z.writestr(info,v)
    return out.getvalue()
x=build();assert x==build()
with zipfile.ZipFile(io.BytesIO(x)) as z:
    assert z.testzip() is None
    for line in z.read('SHA256SUMS.txt').decode().splitlines():
        h,n=line.split('  ',1);assert sha(z.read(n))==h
name='Strattester-ci-qa-'+S[:12]+'.zip';(O/name).write_bytes(x)
(O/'SHA256SUMS.txt').write_text(sha(x)+'  '+name+'\n')
(O/'READINESS_REPORT.md').write_bytes((D/'READINESS_REPORT.md').read_bytes())
(O/'OWNER_REVIEW.template.json').write_bytes((D/'OWNER_REVIEW.template.json').read_bytes())
delivery={'source_sha':S,'archive':name,'sha256':sha(x),'bytes':len(x),'members':len(contents),'two_builds_identical':True,'all_member_hashes_verified':True}
(D/'delivery.json').write_text(json.dumps(delivery,indent=2)+'\n');(O/'delivery.json').write_bytes((D/'delivery.json').read_bytes())
print(json.dumps(delivery))
