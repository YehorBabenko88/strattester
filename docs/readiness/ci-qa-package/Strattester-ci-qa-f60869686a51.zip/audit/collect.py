import subprocess,json,hashlib,zipfile,io,collections,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'evidence'; OUT.mkdir(exist_ok=True)
SHA='f60869686a51693799b4844a1af49c9b39ba45d5'
API='repos/YehorBabenko88/strattester/'
def api(path):
    return subprocess.check_output(['gh','api','--allow-escape-sequences',API+path])
def save(name,data):
    (OUT/name).write_bytes(data)
def obj(path,name):
    b=api(path);save(name,b);return json.loads(b)
pr=obj('pulls/21','source-pr.json');assert pr['head']['sha']==SHA
runs=obj('actions/runs?head_sha='+SHA+'&per_page=100','runs.json')['workflow_runs']
summary={'source_sha':SHA,'runs':[],'artifacts':[],'gates':{},'full_test_summaries':{}}
for run in runs:
    assert run['head_sha']==SHA
    rid=run['id']; jobs=obj(f'actions/runs/{rid}/jobs?per_page=100',f'jobs-{rid}.json')['jobs']
    summary['runs'].append({k:run[k] for k in ('id','name','head_sha','conclusion','html_url','run_attempt')})
    for job in jobs:
        log=api(f"actions/jobs/{job['id']}/logs");save(f"job-{job['id']}.log",log)
        if run['name']=='tests':
            import re
            summary['full_test_summaries'][job['name']]=re.findall(r'[^\n]*\d+ passed[^\n]*',log.decode(errors='replace'))[-1:]
    artifacts=obj(f'actions/runs/{rid}/artifacts?per_page=100',f'artifacts-{rid}.json')['artifacts']
    for a in artifacts:
        b=api(f"actions/artifacts/{a['id']}/zip");h=hashlib.sha256(b).hexdigest()
        assert a['workflow_run']['head_sha']==SHA
        assert a.get('digest')=='sha256:'+h,(a['name'],'digest mismatch')
        save(f"artifact-{a['id']}.zip",b)
        summary['artifacts'].append({'id':a['id'],'name':a['name'],'sha256':h,'bytes':len(b),'api_size':a['size_in_bytes'],'digest_matches':True})
        with zipfile.ZipFile(io.BytesIO(b)) as z:
            assert z.testzip() is None
            for name in z.namelist():
                if name.endswith('.json') and '/' not in name:
                    save(f"extracted-{a['id']}-{name}",z.read(name))
            if a['name'].startswith('financial-') and not a['name'].startswith('financial-acceptance-'):
                gate=a['name'].split('-')[1]
                norm=json.loads(z.read(gate+'.json'));raw=json.loads(z.read(gate+'-pytest.json'))
                spec=json.loads((ROOT/'repo/scripts/financial-gate-manifest.json').read_text())[gate]
                nodes=[t['nodeid'] for t in raw['tests']]
                assert collections.Counter(nodes)==collections.Counter(spec['nodeids'])==collections.Counter(norm['nodeids'])
                assert norm['sha']==SHA and norm['status']=='PASS'
                assert all(t['outcome'] in ('passed','subtests passed') for t in raw['tests'])
                xml=ET.fromstring(z.read(gate+'.xml'))
                cases=list(xml.iter('testcase'))
                # JUnit uses dotted classnames; compare a normalized multiset.
                expected=[n.split('::')[0].removesuffix('.py').replace('/','.')+'.'+'.'.join(n.split('::')[1:]) for n in nodes]
                actual=[c.attrib['classname']+'.'+c.attrib['name'] for c in cases]
                assert collections.Counter(expected)==collections.Counter(actual),(gate,'JUnit mismatch')
                assert not list(xml.iter('skipped')) and not list(xml.iter('failure')) and not list(xml.iter('error'))
                summary['gates'][gate]={'nodes':len(nodes),'raw_summary':raw['summary'],'normalized':{k:v for k,v in norm.items() if k!='nodeids'},'junit_multiset_matches':True}
            if a['name'].startswith('financial-acceptance-'):
                acc=json.loads(z.read('acceptance.json'));assert acc['status']=='BLOCKED' and acc['failed']==[]
                summary['acceptance']=acc
            if a['name'].startswith('native-component-proof-'):
                summary['native']={n:json.loads(z.read(n)) for n in z.namelist() if n.endswith('.json') and n in ('scope.json','diagnose.json','component-native.json','component-handles.json','component-wfp.json','owner-nonce.json')}
                summary['native_files']=z.namelist()
                for n in z.namelist():
                    if n.endswith('.exe'):summary['native_binary_sha256']=hashlib.sha256(z.read(n)).hexdigest()
save('audit-summary.json',(json.dumps(summary,indent=2)+'\n').encode())
print(json.dumps({'runs':len(runs),'artifacts':len(summary['artifacts']),'nodes':sum(v['nodes'] for v in summary['gates'].values()),'acceptance':summary.get('acceptance',{}).get('status')}))

